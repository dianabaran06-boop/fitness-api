const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB({
  region: "eu-central-1",
  apiVersion: "2012-08-10"
});

exports.handler = async (event) => {
  const params = { TableName: "workouts" };

  const data = await dynamodb.scan(params).promise();

  const workouts = data.Items.map(item => ({
    id: item.id.S,
    name: item.name.S,
    type: item.type.S,
    duration: Number(item.duration.N)
  }));

  return workouts;
};