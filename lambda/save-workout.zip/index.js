const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB({
  region: "eu-central-1",
  apiVersion: "2012-08-10"
});

exports.handler = async (event) => {
  const params = {
    TableName: "workouts",
    Item: {
      id: { S: event.id },
      name: { S: event.name },
      type: { S: event.type },
      duration: { N: event.duration.toString() }
    }
  };

  await dynamodb.putItem(params).promise();

  return { message: "Workout saved" };
};