const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB({
  region: "eu-central-1",
  apiVersion: "2012-08-10"
});

exports.handler = async (event) => {
  const params = {
    TableName: "workouts",
    Key: { id: { S: event.id } },
    UpdateExpression: "SET #name = :name, #type = :type, #duration = :duration",
    ExpressionAttributeNames: {
      "#name": "name",
      "#type": "type",
      "#duration": "duration"
    },
    ExpressionAttributeValues: {
      ":name": { S: event.name },
      ":type": { S: event.type },
      ":duration": { N: event.duration.toString() }
    }
  };

  await dynamodb.updateItem(params).promise();

  return { message: "Workout updated" };
};