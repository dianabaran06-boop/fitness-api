const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {

  const id = event.pathParameters?.id;
  const body = JSON.parse(event.body);

  try {
    await dynamo.update({
      TableName: "workouts",
      Key: { id },
      UpdateExpression: "set #name = :name, #type = :type, #duration = :duration",
      ExpressionAttributeNames: {
        "#name": "name",
        "#type": "type",
        "#duration": "duration"
      },
      ExpressionAttributeValues: {
        ":name": body.name,
        ":type": body.type,
        ":duration": body.duration
      }
    }).promise();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ message: "Updated" })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: error.message })
    };
  }
};