const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async () => {
  const params = {
    TableName: process.env.TABLE_NAME
  };

  try {
    const data = await dynamo.scan(params).promise();

    return {
      statusCode: 200,
      body: JSON.stringify(data.Items || [])
    };

  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};