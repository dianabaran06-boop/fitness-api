const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB({
  region: "eu-central-1",
  apiVersion: "2012-08-10"
});

exports.handler = async (event) => {
  try {
    const id = event.pathParameters.id; // беремо id з URL /workouts/{id}

    const params = {
      TableName: "workouts",
      Key: { id: { S: id } }
    };

    await dynamodb.deleteItem(params).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Workout deleted" })
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};