const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB({
  region: "eu-central-1",
  apiVersion: "2012-08-10"
});

exports.handler = async (event) => {
  const params = {
    TableName: "workouts",
    Key: {
      id: { S: event.id }  // передаємо id через event
    }
  };

  const data = await dynamodb.getItem(params).promise();

  if (!data.Item) return { message: "Workout not found" };

  return {
    id: data.Item.id.S,
    name: data.Item.name.S,
    type: data.Item.type.S,
    duration: Number(data.Item.duration.N)
  };
};